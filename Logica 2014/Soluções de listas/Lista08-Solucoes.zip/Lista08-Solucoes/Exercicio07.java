public class Exercicio07 {
	public static void main(String[] args) {
		int cont, idade, otimos, ruins, sIdadesRuins, pessimos;
		int mIdadePessimos, mIdadeRuins, mIdadeOtimos;
		char opiniao;
		
		otimos = ruins = sIdadesRuins =	pessimos = 0;
		mIdadePessimos = mIdadeOtimos = mIdadeRuins = -1;
		
		for(cont = 1; cont <= 100; cont++) {
			System.out.printf("--- PESSOA %03d ---\n", cont);
			System.out.print("Idade...: ");
			idade = Integer.parseInt(System.console().readLine());
			System.out.print("Opiniao.: ");
			opiniao = System.console().readLine().charAt(0);
			if(opiniao == 'A') {
				otimos++;
				if(mIdadeOtimos < idade)
					mIdadeOtimos = idade;
			} else {
				if(opiniao == 'D') {
					ruins++;
					sIdadesRuins += idade;
					if(mIdadeRuins < idade)
						mIdadeRuins = idade;
				} else {
					if(opiniao == 'E') {
						pessimos++;
						if(mIdadePessimos < idade)
							mIdadePessimos = idade;
					}
				}
			}
		}
		
		System.out.printf("Num. de respostas \"Otimo\" = %d\n", otimos);
		if(ruins > 0)
			System.out.printf("Media de idade das pessoas que responderam \"Ruim\" = %d\n", sIdadesRuins/ruins);
		if(pessimos > 0) {
			System.out.printf("Percentual de pessoas que responderam \"Pessimo\" = %d%%\n", pessimos);
			System.out.printf("Maior idade entre as pessoas que responderam \"Pessimo\" = %d\n", mIdadePessimos);
		}
		if(otimos > 0 && ruins > 0)
			System.out.printf("Dif. entre as maiores idades de \"Otimo\" e \"Ruim\" = %d\n", Math.abs(mIdadeOtimos - mIdadeRuins));
	}
}
