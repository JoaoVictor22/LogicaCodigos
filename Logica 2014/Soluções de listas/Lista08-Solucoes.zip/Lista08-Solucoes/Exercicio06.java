public class Exercicio06 {

	public static void main(String[] args) {
	
		// Uma vari�vel basta para armazenar as respostas, j� que nunca vamos precisar das anteriores.
		char resposta;
		
		System.out.print("Eh mamifero?");
		resposta = Character.toUpperCase(System.console().readLine().charAt(0)); // Character.toUpperCase para a letra digitada para mai�sculo.
		if(resposta == 'S') {
			System.out.print("Eh quadrupede? ");
			resposta = Character.toUpperCase(System.console().readLine().charAt(0));
			if(resposta == 'S') {
				System.out.print("Eh carnivoro? ");
				resposta = Character.toUpperCase(System.console().readLine().charAt(0));
				if(resposta == 'S') {
					System.out.println("Ent�o o animal escolhido foi o leao.");
				} else {
					System.out.print("Eh herbivoro? ");
					resposta = Character.toUpperCase(System.console().readLine().charAt(0));
					if(resposta == 'S') {
						System.out.println("Entao o animal escolhido foi o cavalo.");
					} else {
						System.out.println("Nao conheco esse animal.");
					}
				}
			} else {
				System.out.print("Eh bipede? ");
				resposta = Character.toUpperCase(System.console().readLine().charAt(0));
				if(resposta == 'S') {
					System.out.print("Eh onivoro? ");
					resposta = Character.toUpperCase(System.console().readLine().charAt(0));
					if(resposta == 'S') {
						System.out.println("Entao o animal escolhido foi o homem.");
					} else {
						System.out.print("Eh frutivoro? ");
						resposta = Character.toUpperCase(System.console().readLine().charAt(0));
						if(resposta == 'S') {
							System.out.println("Entao o animal escolhido foi o macaco.");
						} else {
							System.out.println("Nao conheco esse animal.");
						}
					}
				} else {
					System.out.print("Eh voador? ");
					resposta = Character.toUpperCase(System.console().readLine().charAt(0));
					if(resposta == 'S') {
						System.out.println("Entao o animal escolhido foi o morcego.");
					} else {
						System.out.print("Eh aquatico? ");
						resposta = Character.toUpperCase(System.console().readLine().charAt(0));
						if(resposta == 'S') {
							System.out.println("Entao o animal escolhido foi a baleia.");
						} else {
							System.out.println("Nao conheco esse animal.");
						}
					}
				}
			}
		} else {
			System.out.print("Eh ave? ");
			resposta = Character.toUpperCase(System.console().readLine().charAt(0));
			if(resposta == 'S') {
				System.out.print("Eh nao-voador? ");
				resposta = Character.toUpperCase(System.console().readLine().charAt(0));
				if(resposta == 'S') {
					System.out.print("Eh tropical? ");
					resposta = Character.toUpperCase(System.console().readLine().charAt(0));
					if(resposta == 'S') {
						System.out.println("Entao o animal escolhido foi o avestruz.");
					} else {
						System.out.print("Eh polar? ");
						resposta = Character.toUpperCase(System.console().readLine().charAt(0));
						if(resposta == 'S') {
							System.out.println("Entao o animal escolhido foi o pinguim.");
						} else {
							System.out.println("Nao conheco esse animal.");
						}
					}
				} else {
					System.out.print("Eh nadador? ");
					resposta = Character.toUpperCase(System.console().readLine().charAt(0));
					if(resposta == 'S') {
						System.out.println("Entao o animal escolhido foi o pato.");
					} else {
						System.out.print("Eh de rapina? ");
						resposta = Character.toUpperCase(System.console().readLine().charAt(0));
						if(resposta == 'S') {
							System.out.println("Entao o animal escolhido foi o aguia.");
						} else {
							System.out.println("Nao conheco esse animal.");
						}
					}
				}
			} else {
				System.out.print("Eh reptil? ");
				resposta = Character.toUpperCase(System.console().readLine().charAt(0));
				if(resposta == 'S') {
					System.out.print("Tem casco? ");
					resposta = Character.toUpperCase(System.console().readLine().charAt(0));
					if(resposta == 'S') {
						System.out.println("Entao o animal escolhido foi a tartaruga.");
					} else {
						System.out.print("Eh carnivoro? ");
						resposta = Character.toUpperCase(System.console().readLine().charAt(0));
						if(resposta == 'S') {
							System.out.println("Entao o animal escolhido foi o crocodilo.");
						} else {
							System.out.print("Eh sem patas? ");
							resposta = Character.toUpperCase(System.console().readLine().charAt(0));
							if(resposta == 'S') {
								System.out.println("Entao o animal escolhido foi a cobra.");
							} else {
								System.out.println("Nao conheco esse animal.");
							}
						}
					}
				} else {
					System.out.println("Nao conheco esse animal.");
				}
			}
		}
	}

}