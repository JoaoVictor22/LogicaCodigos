public class Exercicio09 {

	public static void main(String[] args) {
		int quant50 = 100, quant10 = 100, quant5 = 100, quant1 = 100;
		int num50, num10, num5;
		int valor, saques = 0;
		
		do {
			System.out.print("Valor do saque: ");
			valor = Integer.parseInt(System.console().readLine());
			
			if(valor >= 0) {
				if(valor > 1000) {
					System.out.println("Valor de saque excede o limite de B$1000.");
				} else if (valor > (quant50*50 + quant10*10 + quant5*5 + quant1)){
					System.out.println("Valor de saque excede o valor dispon�vel no caixa.");
					System.out.printf("Valor maximo para saque: B$%d\n", quant50*50 + quant10*10 + quant5*5 + quant1);
				} else {
					saques++;
					
					// Se exitem notas de 50 no caixa
					if(quant50 > 0) {
						num50 = Math.min(valor/50, quant50); // Calcula o n�mero de notas de 50 a serem dadas ao cliente.
						quant50 -= num50; // Desconta isso do total de notas de 50 presentes no caixa.
						valor -= num50*50; // Calcula o resto de dinheiro que sobra.
						if(num50 > 0) // Se foram dadas notas de 50, mostra a quantidade na tela
							System.out.printf("Notas de B$50: %d\n", num50);
					}
					
					// Se exitem notas de 10 no caixa
					if(quant10 > 0) {
						num10 = Math.min(valor/10, quant10); // Calcula o n�mero de notas de 10 a serem dadas ao cliente.
						quant10 -= num10; // Desconta isso do total de notas de 10 presentes no caixa.
						valor -= num10*10; // Calcula o resto de dinheiro que sobra.
						if(num10 > 0) // Se foram dadas notas de 10, mostra a quantidade na tela
							System.out.printf("Notas de B$10: %d\n", num10);
					}
					
					// Se exitem notas de 5 no caixa
					if(quant5 > 0) {
						num5 = Math.min(valor/5, quant5); // Calcula o n�mero de notas de 5 a serem dadas ao cliente.
						quant5 -= num5; // Desconta isso do total de notas de 5 presentes no caixa.
						valor -= num5*5; // Calcula o resto de dinheiro que sobra.
						if(num5 > 0) // Se foram dadas notas de 5, mostra a quantidade na tela
							System.out.printf("Notas de B$5: %d\n", num5);
					}
					
					// Se exitem notas de 1 no caixa
					if(quant1 > 0) {
						quant1 -= valor; // Desconta o restante das notas de 1 presentes no caixa.
						if(valor > 0) // Se foram dadas notas de 1, mostra a quantidade na tela
							System.out.printf("Notas de B$1: %d\n", valor);
					}
				}
			}
		} while(valor >= 0 && saques < 100);
		
		System.out.printf("Restam %d notas de B$ 50, %d notas de B$ 10, %d notas de R$ 5 e %d notas de B$ 1.", quant50, quant10, quant5, quant1);
	}

}