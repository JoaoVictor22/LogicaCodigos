public class Exercicio02 {
	public static void main(String[] args) {
		int contador, tempo_servico;
		double salario, bonus, total;
		char sexo;
		
		total = 0;
		for(contador = 1; contador <= 10; contador++) {
			System.out.printf("--- FUNCIONARIO %02d ---\n", contador);
			System.out.print("Sexo (M para masculino e F para feminino): ");
			sexo = System.console().readLine().charAt(0);
			System.out.print("Tempo de servico (em anos): ");
			tempo_servico = Integer.parseInt(System.console().readLine());
			System.out.print("Salario: ");
			salario = Double.parseDouble(System.console().readLine());
			if(sexo == 'M' && tempo_servico > 15)
				bonus = salario * 0.20;
			else if(sexo == 'F' && tempo_servico > 10)
				bonus = salario * 0.25;
			else
				bonus = 300;
				
			System.out.printf("Bonus recebido pelo funcionario = R$ %.2f\n", bonus);
			
			total += bonus;
		}
		
		System.out.printf("Total pago em bonus = R$ %.2f\n", total);
	}
}
