public class Exercicio04 {
	public static void main(String[] args) {
		int cont, pessoas, sexo, mulheres, homens;
		double altura, maior, menor, soma;
		System.out.print("Informe o numero de pessoas: ");
		pessoas = Integer.parseInt(System.console().readLine());
		soma = 0;
		mulheres = 0;
		homens = 0;
		maior = 0;
		menor = 0;
		
		for(cont = 1; cont <= pessoas; cont++) {
			System.out.printf("--- PESSOA %d ---\n", cont);
			System.out.print("Sexo (1 para masculino e 2 para feminino): ");
			sexo = Integer.parseInt(System.console().readLine());
			System.out.print("Altura (em metros): ");
			altura = Double.parseDouble(System.console().readLine());
			
			// Contabiliza maior e menor altura do grupo
			if(cont == 1)
				maior = menor = altura;
			else {
				if(altura > maior)
					maior = altura;
				if(altura < menor)
					menor = altura;
			}
			
			// Contabiliza dados de mulheres
			if(sexo == 2) {
				soma += altura;
				mulheres++;
			}
			
			// Contabiliza numero de homens
			if(sexo == 1) {
				homens++;
			}
		}
		
		System.out.printf("Maior altura = %.2f\n", maior);
		System.out.printf("Menor altura = %.2f\n", menor);
		if(mulheres > 0) {
			System.out.printf("Media de altura das mulheres = %.2f\n", soma / mulheres);
		}
		System.out.printf("Numero de homens = %d\n", homens);
	}
}
