public class Exercicio01 {
	public static void main(String[] args) {
		int contador;
		double salario, reajuste;
		for(contador = 1; contador <= 15; contador++) {
			System.out.printf("Salario do funcionario %d: ", contador);
			salario = Double.parseDouble(System.console().readLine());
			if(salario < 1000) {
				reajuste = salario * 0.55;
			} else { 
				if(salario <= 2500) {
					reajuste = salario * 0.30;
				}
				else {
					reajuste = salario * 0.20;
				}
			}
			System.out.printf("O reajuste salarial do funcionario %d eh %f\n", contador, reajuste);
		}
			
	}
}
