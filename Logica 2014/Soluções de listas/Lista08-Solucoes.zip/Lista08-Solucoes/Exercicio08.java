public class Exercicio08 {
	public static void main(String[] args) {
		int estrofe;
		String dia, presente;
		dia = "";
		
		System.out.print("Estrofe desejada (zero para musica inteira): ");
		estrofe = Integer.parseInt(System.console().readLine());
		
		if(estrofe == 0) {
			for(estrofe = 1; estrofe <= 12; estrofe++) {
				switch(estrofe) {
					case 1:	dia = "first"; break;
					case 2:	dia = "second"; break;
					case 3:	dia = "third"; break;
					case 4:	dia = "fourth"; break;
					case 5:	dia = "fifth"; break;
					case 6:	dia = "sixth"; break;
					case 7:	dia = "seventh"; break;
					case 8:	dia = "eighth"; break;
					case 9:	dia = "ninth"; break;
					case 10: dia = "tenth"; break;
					case 11: dia = "eleventh"; break;
					case 12: dia = "twelfth"; break;
				}
				System.out.printf("On the %s day of Christmas, my love gave to me ", dia);
				switch(estrofe) {
					case 12: System.out.println("twelve drummers drumming,");
					case 11: System.out.println("eleven pipers piping,");
					case 10: System.out.println("ten lords a-leaping,");
					case 9: System.out.println("nine ladies waiting,");
					case 8: System.out.println("eight maids a-milking,");
					case 7: System.out.println("seven swans a-swimming,");
					case 6: System.out.println("six geese a-laying,");
					case 5: System.out.println("five gold rings,");
					case 4: System.out.println("four calling birds,");
					case 3: System.out.println("three french hens,");
					case 2: System.out.println("two turtle doves,");
					case 1: 
						if(estrofe > 1)
							System.out.print("and ");
						System.out.println("a partridge in a pear tree.");
				}
				System.out.println(); // Mostra uma linha em branco entre cada estrofe.
			}
		} else {
			switch(estrofe) {
				case 1:	dia = "first"; break;
				case 2:	dia = "second"; break;
				case 3:	dia = "third"; break;
				case 4:	dia = "fourth"; break;
				case 5:	dia = "fifth"; break;
				case 6:	dia = "sixth"; break;
				case 7:	dia = "seventh"; break;
				case 8:	dia = "eighth"; break;
				case 9:	dia = "ninth"; break;
				case 10: dia = "tenth"; break;
				case 11: dia = "eleventh"; break;
				case 12: dia = "twelfth"; break;
			}
			System.out.printf("On the %s day of Christmas, my love gave to me ", dia);
			switch(estrofe) {
				case 12: System.out.println("twelve drummers drumming,");
				case 11: System.out.println("eleven pipers piping,");
				case 10: System.out.println("ten lords a-leaping,");
				case 9: System.out.println("nine ladies waiting,");
				case 8: System.out.println("eight maids a-milking,");
				case 7: System.out.println("seven swans a-swimming,");
				case 6: System.out.println("six geese a-laying,");
				case 5: System.out.println("five gold rings,");
				case 4: System.out.println("four calling birds,");
				case 3: System.out.println("three french hens,");
				case 2: System.out.println("two turtle doves,");
				case 1: 
					if(estrofe > 1)
						System.out.print("and ");
					System.out.println("a partridge in a pear tree.");
			}
		}
	}
}