public class Exercicio05 {
	public static void main(String[] args) {
		String vinho;
		int quantT, quantB, quantR;
		double porcT, porcB, porcR;
		
		quantT = quantB = quantR = 0;
		do {
			System.out.print("Tipo do vinho(T - tinto, B - branco, R - rose): ");
			vinho = System.console().readLine();
			if(vinho.equals("T"))
				quantT++;
			else if(vinho.equals("B"))
				quantB++;
			else if(vinho.equals("R"))
				quantR++;
			else if(!vinho.equals("F"))
				System.out.println("Tipo de vinho invalido!");
		} while(!vinho.equals("F"));
		
		porcT = quantT * 100.0 / (quantT + quantB + quantR);
		porcB = quantB * 100.0 / (quantT + quantB + quantR);
		porcR = quantR * 100.0 / (quantT + quantB + quantR);
		
		System.out.printf("Percentual de vinho tinto  = %.1f%%\n", porcT);
		System.out.printf("Percentual de vinho branco = %.1f%%\n", porcB);
		System.out.printf("Percentual de vinho rose   = %.1f%%\n", porcR);
	}
}
