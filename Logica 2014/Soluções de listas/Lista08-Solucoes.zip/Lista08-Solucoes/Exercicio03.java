public class Exercicio03 {
	public static void main(String[] args) {
		int contador, numero, maior, menor;
		System.out.println("Digite 20 numeros inteiros abaixo: ");
		numero = Integer.parseInt(System.console().readLine());
		menor = maior = numero;
		for(contador = 1; contador <= 19; contador++) {
			numero = Integer.parseInt(System.console().readLine());
			
			if(numero > maior)
				maior = numero;
			if(numero < menor)
				menor = numero;
				
			/* SOLUCOES ALTERNATIVAS:
				maior = Math.max(numero, maior);
				menor = Math.min(numero, menor);
			
				maior = numero > maior ? numero : maior;
				menor = numero < menor ? numero : menor;
			 */
		}
		System.out.printf("Maior = %d, Menor = %d\n", maior, menor);
	}
}
