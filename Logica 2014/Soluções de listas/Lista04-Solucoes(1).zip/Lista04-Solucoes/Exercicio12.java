public class Exercicio12 {

	public static void main(String[] args) {
	
		int N, contador;
		double h;
		
		System.out.print("Valor de N: ");
		N = Integer.parseInt(System.console().readLine());
		
		contador = 1;
		h = 0;
		while(contador <= N) {
			h = h + 1.0/contador;
			contador = contador + 1;
		}
		System.out.printf("H = %f\n", h);
		
	}

}