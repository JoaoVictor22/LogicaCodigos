public class Exercicio01 {

	public static void main(String[] args) {
		String entrada;
		int numero, soma, contador;
		
		soma = 0;
		contador = 1;
		while(contador <= 10) {
			System.out.printf("Digite o %do numero inteiro: ", contador);
			numero = Integer.parseInt(System.console().readLine());
			soma = soma + numero;
			contador = contador + 1;
		}

		System.out.printf("A soma dos 10 numeros digitados eh %d\n", soma);
	}

}