public class Exercicio02 {

	public static void main(String[] args) {
		String entrada;
		int n, contador, soma, somaquad;
		double media;
		
		System.out.print("Digite um numero inteiro positivo: ");
		entrada = System.console().readLine();
		n = Integer.parseInt(entrada);

		soma = 0;
		somaquad = 0;
		contador = 1;
		while(contador <= n) {
			soma = soma + contador;
			somaquad = somaquad + contador * contador;
			contador = contador + 1;
		}
		media = (double)soma/n; // Colocar (double) na frente do nome de uma vari�vel usa o valor dela como se um do tipo double.

		System.out.printf("A soma dos numeros de 1 a %d eh %d\n", n, soma);
		System.out.printf("A soma dos quadrados do numeros de 1 a %d eh %d\n", n, somaquad);
		System.out.printf("A media dos numeros de 1 a %d eh %f\n", n, media);
	}
}