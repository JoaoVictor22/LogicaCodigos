public class Exercicio03 {
	public static void main(String[] args) {
		int num, quad;
		System.out.print("Digite um numero inteiro: ");
		num = Integer.parseInt(System.console().readLine());
		while(num >= 0) {
			quad = num * num;
			System.out.printf("O quadrado de %d eh %d\n", num, quad);
			System.out.print("Digite um numero inteiro: ");
			num = Integer.parseInt(System.console().readLine());
		}
	}
}