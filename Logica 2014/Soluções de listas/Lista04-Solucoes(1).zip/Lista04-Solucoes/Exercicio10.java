public class Exercicio10 {

	public static void main(String[] args) {
	
		int expoente, potencia;
		
		potencia = 1;
		expoente = 0;
		while(expoente <= 15) {
            System.out.printf("3 ^ %d = %d\n", expoente, potencia);
            potencia = potencia * 3;
            expoente = expoente + 1;
		}
	
	}

}