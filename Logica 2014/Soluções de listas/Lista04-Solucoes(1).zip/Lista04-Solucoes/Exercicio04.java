public class Exercicio04 {
	public static void main(String[] args) {
		int x, fx;
		System.out.print("Valor de x: ");
		x = Integer.parseInt(System.console().readLine());
		while(x != 0) {
			fx = x * x - 5 * x + 6;
			System.out.printf("F(x) = %d\n", fx);
			System.out.print("Valor de x: ");
			x = Integer.parseInt(System.console().readLine());
		}
	}
}