public class Exercicio05 {

	public static void main(String[] args) {
		String entrada;
		int contador, quantidade, produtos;
		String nome;
		double preco, fatTotal;
		
		System.out.print("Numero de mercadorias: ");
		produtos = Integer.parseInt(System.console().readLine());
		
		fatTotal = 0;
		contador = 1;
		while(contador <= produtos) {
			System.out.printf("--- PRODUTO %d ---\n", contador);
            System.out.print("Nome do produto....: ");
            nome = System.console().readLine();
            System.out.print("Preco..............: ");
			entrada = System.console().readLine();
            preco = Double.parseDouble(entrada);
            System.out.print("Quantidade vendida.: ");
			entrada = System.console().readLine();
            quantidade = Integer.parseInt(entrada);
            fatTotal += preco*quantidade;
            contador++;
		}
		System.out.printf("Faturamento total do armaz�m: R$ %.2f\n", fatTotal);
	}
}