public class Exercicio09 {

	public static void main(String[] args) {
	
		int numero;
		
		numero = 1;
		while(numero <= 20) {
			System.out.println(numero);
            numero = numero + 2;
		}
	
	}

}