public class Exercicio06 {

	public static void main(String[] args) {
		int numero, quad;
		numero = 15;
		while(numero <= 200) {
			quad = numero * numero;
            System.out.printf("%d * %d = %d\n", numero, numero, quad);
            numero = numero + 1;
		}
	}

}