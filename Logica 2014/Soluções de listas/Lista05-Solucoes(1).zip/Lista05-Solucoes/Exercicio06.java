public class Exercicio06 {
	public static void main(String[] args) {
		int segundos, minutos, horas;
		System.out.print("Quantidade de tempo em segundos: ");
		segundos = Integer.parseInt(System.console().readLine());
		horas = segundos / 3600;
		segundos = segundos - horas * 3600;
		minutos = segundos / 60;
		segundos = segundos - minutos * 60;
		System.out.printf("Temos: %d horas, %d minutos e %d segundos.", horas, minutos, segundos);
	}
}