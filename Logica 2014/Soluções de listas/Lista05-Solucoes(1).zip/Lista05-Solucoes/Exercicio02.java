public class Exercicio02 {
	public static void main(String[] args) {
		int contador;
		double s;
		s = 0;
		contador = 1;
		while(contador <= 50) {
			s = s + (contador * 2.0 - 1.0) / contador; // Escrevi 2.0 e 1.0 para que o resultado da divis�o seja double.
			contador = contador + 1;
		}
		System.out.printf("S = %f\n", s);
	}
}