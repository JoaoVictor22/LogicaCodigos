public class Exercicio04 {
	public static void main(String[] args) {
		int viagens, contador;
		double litros_comb, distancia, soma_medias, media;
		System.out.print("Informe o numero de viagens efetuadas: ");
		viagens = Integer.parseInt(System.console().readLine());
		soma_medias = 0;
		contador = 0;
		while(contador < viagens) {
			System.out.printf("--- VIAGEM %02d ---\n", contador + 1);
			System.out.print("Litros de Combustivel Gastos: ");
			litros_comb = Double.parseDouble(System.console().readLine());
			System.out.print("Distancia percorrida: ");
			distancia = Double.parseDouble(System.console().readLine());
			soma_medias = soma_medias + distancia / litros_comb;
			contador = contador + 1;
		}
		media = soma_medias / viagens;
		System.out.printf("Media de consumo das viagens = %.2f km/l.\n", media);
	}
}