public class Exercicio05 {
	public static void main(String[] args) {
		int popA, popB, anos;
		popA = 90000000;
		popB = 200000000;
		anos = 0;
		while(popA < popB) {
			popA = popA + popA * 3 / 100;
			popB = popB + popB * 15 / 1000;
			anos = anos + 1;
		}
		System.out.printf("Numero de anos necessarios = %d.", anos);
	}
}