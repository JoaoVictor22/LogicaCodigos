public class Exercicio08 {
	public static void main(String[] args) {
		int contador, sinal;
		double termo, soma;
		soma = 0;
		contador = 0;
		sinal = 1;
		while(contador < 30) {
			termo = (480.0 - contador * 5.0) / (10.0 + contador);
			soma = soma + termo * sinal;
			sinal = sinal * (-1);
			contador = contador + 1;
		}
		System.out.printf("Somatorio = %f\n", soma);
	}
}