public class Exercicio03_08_DoWhile {
	public static void main(String[] args) {
		int numero, soma;
		
		soma = 0;
		numero = 2;	
		do {
			soma = soma + numero;
            numero = numero + 2; 
		} while(numero <= 500);
		
		System.out.printf("A soma dos n�meros pares de 1 a 500 � %d\n", soma);
	}
}