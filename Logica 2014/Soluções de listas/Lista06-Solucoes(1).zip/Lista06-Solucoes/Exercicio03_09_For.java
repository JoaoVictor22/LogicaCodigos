public class Exercicio03_09_For {
	public static void main(String[] args) {
		int numero;
		
		for(numero = 1; numero <= 20; numero = numero + 2) {
			System.out.println(numero);
		}
	}
}