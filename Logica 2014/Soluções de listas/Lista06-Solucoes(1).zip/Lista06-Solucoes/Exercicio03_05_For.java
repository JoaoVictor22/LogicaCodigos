public class Exercicio03_05_For {

	public static void main(String[] args) {
		int contador, quantidade, produtos;
		String nome;
		double preco, fatTotal;
		
		System.out.print("Numero de mercadorias: ");
		produtos = Integer.parseInt(System.console().readLine());
		
		fatTotal = 0;
		for(contador = 1; contador <= produtos; contador = contador + 1) {
			System.out.printf("--- PRODUTO %d ---\n", contador);
            System.out.print("Nome do produto....: ");
            nome = System.console().readLine();
            System.out.print("Preco..............: ");
            preco = Double.parseDouble(System.console().readLine());
            System.out.print("Quantidade vendida.: ");
            quantidade = Integer.parseInt(System.console().readLine());
            fatTotal = fatTotal + preco*quantidade;
		}
		System.out.printf("Faturamento total do armaz�m: R$ %.2f\n", fatTotal);
	}
}