public class Exercicio03_06_DoWhile {

	public static void main(String[] args) {
		int numero, quad;
		numero = 15;
		do {
			quad = numero * numero;
            System.out.printf("%d * %d = %d\n", numero, numero, quad);
            numero = numero + 1;
		} while(numero <= 200);
	}

}