public class Exercicio03_06_For {

	public static void main(String[] args) {
		int numero, quad;
		for(numero = 15; numero <= 200; numero = numero + 1) {
			quad = numero * numero;
            System.out.printf("%d * %d = %d\n", numero, numero, quad);
		}
	}

}