public class Exercicio03_07_DoWhile {

	public static void main(String[] args) {
		int numero, cont, mult;
		
		System.out.print("Digite um numero inteiro: ");
		numero = Integer.parseInt(System.console().readLine());
		
		cont = 1;
		do {
			mult = numero * cont;
			System.out.printf("%d x %d = %d\n", numero, cont, mult);
			cont = cont + 1;
		} while(cont <= 10);
	}
}