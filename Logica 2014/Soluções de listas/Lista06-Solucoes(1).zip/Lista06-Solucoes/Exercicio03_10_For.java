public class Exercicio03_10_For {

	public static void main(String[] args) {
	
		int expoente, potencia;
		
		potencia = 1;
		for(expoente = 0; expoente <= 15; expoente = expoente + 1) {
            System.out.printf("3 ^ %d = %d\n", expoente, potencia);
            potencia = potencia * 3;
		}
	
	}

}