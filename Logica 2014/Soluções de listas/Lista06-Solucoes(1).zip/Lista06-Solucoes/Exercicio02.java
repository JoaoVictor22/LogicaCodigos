public class Exercicio02 {
	public static void main(String[] args) {
		int placa;
		System.out.print("Digite os quatro digitos numericos da placa do veiculo: ");
		placa = Integer.parseInt(System.console().readLine());
		switch(placa % 10) {
			case 0: System.out.println("Vistoria em Janeiro/2014"); break;
			case 1: System.out.println("Vistoria em Fevereiro/2014"); break;
			case 2: System.out.println("Vistoria em Mar�o/2014"); break;
			case 3: System.out.println("Vistoria em Abril/2014"); break;
			case 4: System.out.println("Vistoria em Maio/2014"); break;
			case 5: System.out.println("Vistoria em Junho/2014"); break;
			case 6: System.out.println("Vistoria em Setembro/2013"); break;
			case 7: System.out.println("Vistoria em Outubro/2013"); break;
			case 8: System.out.println("Vistoria em Novembro/2013"); break;
			case 9: System.out.println("Vistoria em Dezembro/2013"); break;
		}
	}
}