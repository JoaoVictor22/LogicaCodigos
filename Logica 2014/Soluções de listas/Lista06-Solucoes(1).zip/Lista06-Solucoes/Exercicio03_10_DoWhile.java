public class Exercicio03_10_DoWhile {

	public static void main(String[] args) {
	
		int expoente, potencia;
		
		potencia = 1;
		expoente = 0;
		do {
            System.out.printf("3 ^ %d = %d\n", expoente, potencia);
            potencia = potencia * 3;
            expoente = expoente + 1;
		} while(expoente <= 15);
	
	}

}