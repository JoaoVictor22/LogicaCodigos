public class Exercicio01 {
	public static void main(String[] args) {
		int dia, mes, ano;
		String mes_extenso;
		
		System.out.print("Dia: ");
		dia = Integer.parseInt(System.console().readLine());
		System.out.print("Mes: ");
		mes = Integer.parseInt(System.console().readLine());
		System.out.print("Ano: ");
		ano = Integer.parseInt(System.console().readLine());
		
		mes_extenso = "";
		switch(mes) {
			case 1: mes_extenso = "janeiro"; break;
			case 2: mes_extenso = "fevereiro"; break;
			case 3: mes_extenso = "mar�o"; break;
			case 4: mes_extenso = "abril"; break;
			case 5: mes_extenso = "maio"; break;
			case 6: mes_extenso = "junho"; break;
			case 7: mes_extenso = "julho"; break;
			case 8: mes_extenso = "agosto"; break;
			case 9: mes_extenso = "setembro"; break;
			case 10: mes_extenso = "outubro"; break;
			case 11: mes_extenso = "novembro"; break;
			case 12: mes_extenso = "dezembro"; break;
		}
		
		if(mes_extenso.equals(""))
			System.out.println("Mes invalido!");
		else
			System.out.printf("%d de %s de %d\n", dia, mes_extenso, ano);
	}
}