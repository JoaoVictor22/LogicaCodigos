public class Exercicio03_08_For {
	public static void main(String[] args) {
		int numero, soma;
		
		soma = 0;
		for(numero = 2; numero <= 500; numero = numero + 2) {
			soma = soma + numero;
		}
		
		System.out.printf("A soma dos n�meros pares de 1 a 500 � %d\n", soma);
	}
}