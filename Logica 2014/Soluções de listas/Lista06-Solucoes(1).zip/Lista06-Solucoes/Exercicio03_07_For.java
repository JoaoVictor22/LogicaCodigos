public class Exercicio03_07_For {

	public static void main(String[] args) {
		int numero, cont, mult;
		
		System.out.print("Digite um numero inteiro: ");
		numero = Integer.parseInt(System.console().readLine());
		
		for(cont = 1; cont <= 10; cont = cont + 1) {
			mult = numero * cont;
			System.out.printf("%d x %d = %d\n", numero, cont, mult);
		}
	}
}